python3 -m http.server $1
